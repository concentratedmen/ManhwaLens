package com.manhwalens.en.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlin.math.min
import kotlin.math.sqrt

/** Thread-safe wrapper: PdfRenderer allows only one open page at a time. */
class PdfSource private constructor(private val pfd: ParcelFileDescriptor) : AutoCloseable {

    private val renderer = PdfRenderer(pfd)
    private val lock = Mutex()

    val pageCount: Int get() = renderer.pageCount

    suspend fun render(index: Int, quality: RenderQuality): Bitmap = lock.withLock {
        withContext(Dispatchers.IO) {
            renderer.openPage(index).use { page ->
                val pw = page.width.toFloat()
                val ph = page.height.toFloat()
                val byWidth = quality.targetWidth / pw
                val byBudget = sqrt(RenderQuality.MAX_PIXELS / (pw * ph))
                val scale = min(byWidth, byBudget)
                val w = (pw * scale).toInt().coerceAtLeast(1)
                val h = (ph * scale).toInt().coerceAtLeast(1)
                val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(Color.WHITE) // PDFs render transparent otherwise
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                bmp
            }
        }
    }

    override fun close() {
        runCatching { renderer.close() }
        runCatching { pfd.close() }
    }

    companion object {
        fun open(context: Context, uri: Uri): PdfSource {
            val pfd = context.contentResolver.openFileDescriptor(uri, "r")
                ?: error("Could not open file")
            return try { PdfSource(pfd) } catch (e: Exception) { pfd.close(); throw e }
        }
    }
}
