package com.manhwalens.en.pipeline

import android.graphics.Bitmap
import com.manhwalens.en.bubble.BubbleFilter
import com.manhwalens.en.bubble.BubbleGrouper
import com.manhwalens.en.bubble.TextNormalizer
import com.manhwalens.en.ocr.OcrEngine
import com.manhwalens.en.render.BubbleRenderer
import com.manhwalens.en.render.RenderItem
import com.manhwalens.en.translate.TextTranslator

data class TranslateOptions(val skipSfx: Boolean = true, val uppercase: Boolean = true)

class TranslationPipeline(private val ocr: OcrEngine, private val translator: TextTranslator) {

    /** Returns a new bitmap with English text, or [src] itself when no dialogue was found. */
    suspend fun translatePage(src: Bitmap, opts: TranslateOptions): Bitmap {
        val blocks = ocr.detect(src)
        if (blocks.isEmpty()) return src
        val medianLh = blocks.map { it.lineHeight }.sorted()[blocks.size / 2]
        val bubbles = BubbleGrouper.group(blocks).filter { BubbleFilter.keep(it, medianLh, opts.skipSfx) }
        if (bubbles.isEmpty()) return src

        val english = translator.translate(bubbles.map { TextNormalizer.forTranslation(it.text) })
        val items = bubbles.zip(english)
            .filter { it.second.isNotBlank() }
            .map { (b, en) -> RenderItem(b.rect, en, b.lineHeight) }
        return BubbleRenderer(opts.uppercase).render(src, items)
    }
}
