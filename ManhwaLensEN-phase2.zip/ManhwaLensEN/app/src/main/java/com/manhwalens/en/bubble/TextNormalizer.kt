package com.manhwalens.en.bubble

object TextNormalizer {
    /** Joins OCR lines into one sentence and un-shouts ALL CAPS so the translator behaves better. */
    fun forTranslation(raw: String): String {
        var t = raw.replace(Regex("-\\s*\\n"), "")
            .replace(Regex("\\s*\\n\\s*"), " ")
            .replace(Regex("\\s{2,}"), " ")
            .trim()
        val letters = t.count { it.isLetter() }
        if (letters >= 4 && t.count { it.isUpperCase() }.toFloat() / letters > 0.8f) {
            t = t.lowercase()
            t = Regex("(^|[.!?]\\s+)(\\p{L})").replace(t) { it.groupValues[1] + it.groupValues[2].uppercase() }
        }
        return t
    }

    fun forDisplay(s: String, uppercase: Boolean): String = s.trim().let { if (uppercase) it.uppercase() else it }
}
