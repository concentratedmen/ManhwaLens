package com.manhwalens.en.bubble

object BubbleFilter {
    /** Drops OCR garbage always; drops big stylised SFX only when [skipSfx] is on. */
    fun keep(b: Bubble, medianLineHeight: Float, skipSfx: Boolean): Boolean {
        val letters = b.text.count { it.isLetter() }
        if (letters < 2) return false
        if (letters.toFloat() / b.text.count { !it.isWhitespace() }.coerceAtLeast(1) < 0.5f) return false
        if (skipSfx) {
            val allCaps = b.text.none { it.isLowerCase() }
            val bigType = b.lineHeight > medianLineHeight * 1.6f
            if (letters <= 12 && allCaps && bigType) return false
        }
        return true
    }
}
