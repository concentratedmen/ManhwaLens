package com.manhwalens.en.render

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.max

data class BgSample(val color: Int, val complex: Boolean)

/** Samples two thin rings just outside the text box; median colour = bubble fill. */
object BackgroundSampler {
    fun sample(bmp: Bitmap, r: Rect, lineHeight: Float): BgSample {
        val rs = ArrayList<Int>(); val gs = ArrayList<Int>(); val bs = ArrayList<Int>()
        fun add(x: Int, y: Int) {
            if (x in 0 until bmp.width && y in 0 until bmp.height) {
                val p = bmp.getPixel(x, y)
                rs += Color.red(p); gs += Color.green(p); bs += Color.blue(p)
            }
        }
        for (ring in 1..2) {
            val m = (max(3f, lineHeight * 0.2f) * ring).toInt()
            val l = r.left - m; val rr = r.right + m; val t = r.top - m; val b = r.bottom + m
            val sx = max(1, (rr - l) / 30); val sy = max(1, (b - t) / 30)
            var x = l
            while (x <= rr) { add(x, t); add(x, b); x += sx }
            var y = t
            while (y <= b) { add(l, y); add(rr, y); y += sy }
        }
        if (rs.isEmpty()) return BgSample(Color.WHITE, false)
        val mr = rs.sorted()[rs.size / 2]; val mg = gs.sorted()[gs.size / 2]; val mb = bs.sorted()[bs.size / 2]
        val medLum = lum(mr, mg, mb)
        val mad = rs.indices.map { abs(lum(rs[it], gs[it], bs[it]) - medLum) }.average()
        return BgSample(Color.rgb(mr, mg, mb), mad > 25.0)
    }

    fun lum(r: Int, g: Int, b: Int): Double = 0.299 * r + 0.587 * g + 0.114 * b
}
