package com.manhwalens.en.translate

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.tasks.await

/** Provider interface. Phase 3 adds Gemini + fallback chain behind the same shape. */
interface TextTranslator {
    val name: String
    suspend fun translate(texts: List<String>): List<String>
}

class MlKitTranslator : TextTranslator {
    override val name = "ML Kit (on-device)"

    private val client = Translation.getClient(
        TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.INDONESIAN)
            .setTargetLanguage(TranslateLanguage.ENGLISH)
            .build()
    )

    /** One-time ~30 MB download; fully offline afterwards. */
    suspend fun ensureModel() {
        client.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
    }

    override suspend fun translate(texts: List<String>): List<String> =
        texts.map { client.translate(it).await() }

    fun close() = client.close()
}
