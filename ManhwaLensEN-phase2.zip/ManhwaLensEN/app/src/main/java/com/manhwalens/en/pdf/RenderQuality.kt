package com.manhwalens.en.pdf

/**
 * Target bitmap width in pixels. Height follows the page aspect ratio,
 * then [MAX_PIXELS] caps the total size so tall webtoon pages can't OOM.
 */
enum class RenderQuality(val label: String, val targetWidth: Int) {
    DRAFT("Draft", 900),
    STANDARD("Standard", 1280),
    HIGH("High", 1600),
    ULTRA("Ultra", 2000);

    companion object {
        /** ~12 MP ≈ 48 MB ARGB_8888. Lower to 8_000_000 on 3 GB RAM devices. */
        const val MAX_PIXELS = 12_000_000
    }
}
