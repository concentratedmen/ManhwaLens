package com.manhwalens.en.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.manhwalens.en.bubble.TextNormalizer
import kotlin.math.max

data class RenderItem(val rect: Rect, val text: String, val lineHeight: Float)

/** Erases original text with the sampled bubble colour, then draws auto-fitted, centred English. */
class BubbleRenderer(private val uppercase: Boolean) {

    private class Fit(val layout: StaticLayout, val fits: Boolean)

    fun render(src: Bitmap, items: List<RenderItem>): Bitmap {
        val out = src.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(out)
        val bounds = RectF(0f, 0f, out.width.toFloat(), out.height.toFloat())
        // Sample from the untouched source so earlier fills never pollute later samples.
        val samples = items.map { BackgroundSampler.sample(src, it.rect, it.lineHeight) }
        val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        }

        items.forEachIndexed { idx, item ->
            val bg = samples[idx]
            val pad = max(4f, item.lineHeight * 0.35f)
            val area = RectF(item.rect).apply { inset(-pad, -pad); intersect(bounds) }
            val text = TextNormalizer.forDisplay(item.text, uppercase)
            val minSize = max(12f, item.lineHeight * 0.55f)
            val maxSize = max(minSize, item.lineHeight * 1.05f)

            var fit = fit(text, textPaint, area, minSize, maxSize)
            var tries = 0
            // Plain bubbles may grow a little when the English is longer than the Indonesian.
            while (!fit.fits && !bg.complex && tries < 3) {
                area.inset(-area.width() * 0.06f, -area.height() * 0.06f)
                area.intersect(bounds)
                fit = fit(text, textPaint, area, minSize, maxSize)
                tries++
            }

            val radius = item.lineHeight * 0.4f
            fillPaint.color = bg.color
            canvas.drawRoundRect(area, radius, radius, fillPaint)

            val dark = BackgroundSampler.lum(Color.red(bg.color), Color.green(bg.color), Color.blue(bg.color)) > 128
            val fillColor = if (dark) 0xFF111111.toInt() else Color.WHITE
            val strokeColor = if (dark) Color.WHITE else Color.BLACK

            canvas.save()
            canvas.translate(area.left + (area.width() - fit.layout.width) / 2f,
                area.top + (area.height() - fit.layout.height) / 2f)
            if (bg.complex) {
                textPaint.style = Paint.Style.STROKE
                textPaint.strokeWidth = textPaint.textSize * 0.2f
                textPaint.strokeJoin = Paint.Join.ROUND
                textPaint.color = strokeColor
                fit.layout.draw(canvas)
            }
            textPaint.style = Paint.Style.FILL
            textPaint.color = fillColor
            fit.layout.draw(canvas)
            canvas.restore()
        }
        return out
    }

    private fun fit(text: String, paint: TextPaint, area: RectF, minSize: Float, maxSize: Float): Fit {
        val w = area.width() * 0.94f
        val h = area.height() * 0.94f
        var lo = minSize
        var hi = maxSize
        repeat(8) {
            val mid = (lo + hi) / 2f
            if (layout(text, paint, mid, w).height <= h) lo = mid else hi = mid
        }
        val layout = layout(text, paint, lo, w) // leaves paint.textSize = lo for drawing
        val widest = (0 until layout.lineCount).maxOfOrNull { layout.getLineWidth(it) } ?: 0f
        return Fit(layout, layout.height <= h && widest <= w + 1f)
    }

    private fun layout(text: String, paint: TextPaint, size: Float, width: Float): StaticLayout {
        paint.textSize = size
        return StaticLayout.Builder.obtain(text, 0, text.length, paint, width.toInt().coerceAtLeast(1))
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setIncludePad(false)
            .setBreakStrategy(Layout.BREAK_STRATEGY_BALANCED)
            .setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_NONE)
            .build()
    }
}
