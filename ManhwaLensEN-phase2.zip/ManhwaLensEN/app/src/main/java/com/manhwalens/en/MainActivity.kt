package com.manhwalens.en

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.manhwalens.en.ui.home.HomeScreen
import com.manhwalens.en.ui.theme.ManhwaLensTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { ManhwaLensTheme { HomeScreen() } }
    }
}
