package com.manhwalens.en.store

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File

/** Translated pages live in app-private storage (survives restarts; Phase 4 reader reads from here). */
class PageStore(context: Context, docKey: String) {
    private val dir = File(context.filesDir, "translated/$docKey").apply { mkdirs() }

    fun file(index: Int) = File(dir, "page_${index.toString().padStart(4, '0')}.jpg")

    fun save(index: Int, bmp: Bitmap) {
        file(index).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
    }

    fun load(index: Int): Bitmap? = file(index).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }

    fun savedPages(): Set<Int> = dir.listFiles()
        ?.mapNotNull { it.name.removePrefix("page_").removeSuffix(".jpg").toIntOrNull() }
        ?.toSet() ?: emptySet()
}
