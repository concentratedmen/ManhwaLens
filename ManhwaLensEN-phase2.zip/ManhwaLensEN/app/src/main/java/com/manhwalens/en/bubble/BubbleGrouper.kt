package com.manhwalens.en.bubble

import android.graphics.Rect
import com.manhwalens.en.ocr.OcrBlock
import kotlin.math.max
import kotlin.math.min

data class Bubble(val rect: Rect, val text: String, val lineHeight: Float)

/** Merges nearby OCR blocks of similar text size into one speech bubble so sentences translate whole. */
object BubbleGrouper {
    fun group(blocks: List<OcrBlock>): List<Bubble> {
        val n = blocks.size
        val parent = IntArray(n) { it }
        fun find(x: Int): Int {
            var a = x
            while (parent[a] != a) { parent[a] = parent[parent[a]]; a = parent[a] }
            return a
        }
        for (i in 0 until n) for (j in i + 1 until n) {
            if (shouldMerge(blocks[i], blocks[j])) parent[find(i)] = find(j)
        }
        return blocks.indices.groupBy { find(it) }.values.map { idx ->
            val members = idx.map { blocks[it] }.sortedWith(compareBy({ it.rect.top }, { it.rect.left }))
            val rect = Rect(members[0].rect)
            members.forEach { rect.union(it.rect) }
            Bubble(rect, members.joinToString("\n") { it.text }, members.map { it.lineHeight }.average().toFloat())
        }.sortedBy { it.rect.top }
    }

    private fun shouldMerge(a: OcrBlock, b: OcrBlock): Boolean {
        val lh = min(a.lineHeight, b.lineHeight).coerceAtLeast(1f)
        val similarSize = max(a.lineHeight, b.lineHeight) / lh < 1.5f
        val vGap = max(a.rect.top, b.rect.top) - min(a.rect.bottom, b.rect.bottom)
        val overlapW = min(a.rect.right, b.rect.right) - max(a.rect.left, b.rect.left)
        val minW = min(a.rect.width(), b.rect.width())
        return similarSize && vGap < lh * 0.9f && overlapW > 0.4f * minW
    }
}
