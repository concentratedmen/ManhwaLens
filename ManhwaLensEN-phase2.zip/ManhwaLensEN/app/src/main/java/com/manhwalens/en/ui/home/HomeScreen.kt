package com.manhwalens.en.ui.home

import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.manhwalens.en.pdf.RenderQuality

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(vm: HomeViewModel = viewModel()) {
    val st by vm.state.collectAsStateWithLifecycle()
    val ctx = LocalContext.current

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        val name = ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val col = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && col >= 0) c.getString(col) else null
        }
        vm.openPdf(uri, name)
    }

    Scaffold(topBar = { TopAppBar(title = { Text("ManhwaLens EN") }) }) { pad ->
        Column(
            Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Button(onClick = { picker.launch(arrayOf("application/pdf")) }, Modifier.fillMaxWidth(), enabled = !st.translating) {
                Text(if (st.fileName == null) "Choose Indonesian PDF" else "Choose another PDF")
            }
            st.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }

            if (st.pageCount > 0) {
                Text("${st.fileName} · ${st.pageCount} pages · ${st.savedPages.size} translated",
                    style = MaterialTheme.typography.titleMedium)

                Text("Render quality", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    RenderQuality.entries.forEach { q ->
                        FilterChip(selected = st.quality == q, onClick = { vm.setQuality(q) },
                            label = { Text(q.label) }, enabled = !st.translating)
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = st.showOriginal || st.translated == null,
                        onClick = { vm.setShowOriginal(true) }, label = { Text("Original") })
                    FilterChip(selected = !st.showOriginal && st.translated != null,
                        onClick = { vm.setShowOriginal(false) }, label = { Text("English") },
                        enabled = st.translated != null)
                }

                val shown = if (st.showOriginal || st.translated == null) st.original else st.translated
                Box(Modifier.fillMaxWidth().heightIn(min = 240.dp), contentAlignment = Alignment.Center) {
                    shown?.let {
                        Image(bitmap = it.asImageBitmap(), contentDescription = "Page ${st.currentPage + 1}",
                            contentScale = ContentScale.FillWidth, modifier = Modifier.fillMaxWidth())
                    }
                    if (st.loading) CircularProgressIndicator()
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = { vm.showPage(st.currentPage - 1) }, enabled = st.currentPage > 0) { Text("Prev") }
                    Text("Page ${st.currentPage + 1} / ${st.pageCount}")
                    OutlinedButton(onClick = { vm.showPage(st.currentPage + 1) }, enabled = st.currentPage < st.pageCount - 1) { Text("Next") }
                }

                HorizontalDivider()
                SwitchRow("Skip sound effects (SFX)", st.skipSfx, vm::setSkipSfx)
                SwitchRow("Comic-style CAPS lettering", st.uppercase, vm::setUppercase)

                Text("Pages to translate", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(st.rangeStart, vm::setRangeStart, Modifier.weight(1f), label = { Text("From") }, singleLine = true, enabled = !st.translating)
                    OutlinedTextField(st.rangeEnd, vm::setRangeEnd, Modifier.weight(1f), label = { Text("To") }, singleLine = true, enabled = !st.translating)
                }
                Button(onClick = vm::translateRange, enabled = !st.translating, modifier = Modifier.fillMaxWidth()) {
                    Text("Translate range")
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = vm::translateCurrent, enabled = !st.translating, modifier = Modifier.weight(1f)) { Text("This page") }
                    OutlinedButton(onClick = vm::translateAll, enabled = !st.translating, modifier = Modifier.weight(1f)) { Text("Whole chapter") }
                }

                if (st.translating) {
                    LinearProgressIndicator(
                        progress = { if (st.total == 0) 0f else st.progress / st.total.toFloat() },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Text("${st.progress} / ${st.total} · ${st.status ?: ""}")
                    OutlinedButton(onClick = vm::cancelTranslation, Modifier.fillMaxWidth()) { Text("Cancel") }
                } else st.status?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
            }
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
