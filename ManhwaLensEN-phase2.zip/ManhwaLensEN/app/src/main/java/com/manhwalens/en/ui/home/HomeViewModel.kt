package com.manhwalens.en.ui.home

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.manhwalens.en.ocr.OcrEngine
import com.manhwalens.en.pdf.PdfSource
import com.manhwalens.en.pdf.RenderQuality
import com.manhwalens.en.pipeline.TranslateOptions
import com.manhwalens.en.pipeline.TranslationPipeline
import com.manhwalens.en.store.PageStore
import com.manhwalens.en.translate.MlKitTranslator
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class HomeState(
    val fileName: String? = null,
    val pageCount: Int = 0,
    val currentPage: Int = 0,
    val quality: RenderQuality = RenderQuality.STANDARD,
    val original: Bitmap? = null,
    val translated: Bitmap? = null,
    val showOriginal: Boolean = false,
    val loading: Boolean = false,
    val error: String? = null,
    val rangeStart: String = "1",
    val rangeEnd: String = "1",
    val skipSfx: Boolean = true,
    val uppercase: Boolean = true,
    val translating: Boolean = false,
    val progress: Int = 0,
    val total: Int = 0,
    val status: String? = null,
    val savedPages: Set<Int> = emptySet(),
)

class HomeViewModel(app: Application) : AndroidViewModel(app) {
    private val _state = MutableStateFlow(HomeState())
    val state: StateFlow<HomeState> = _state

    private var source: PdfSource? = null
    private var store: PageStore? = null
    private var renderJob: Job? = null
    private var translateJob: Job? = null

    private val ocr by lazy { OcrEngine() }
    private val translator by lazy { MlKitTranslator() }
    private val pipeline by lazy { TranslationPipeline(ocr, translator) }

    fun openPdf(uri: Uri, name: String?) {
        renderJob?.cancel(); translateJob?.cancel()
        source?.close(); source = null
        try {
            val s = PdfSource.open(getApplication(), uri)
            val st = PageStore(getApplication(), uri.toString().hashCode().toString(16))
            source = s; store = st
            _state.update {
                HomeState(
                    fileName = name ?: "Manhwa.pdf",
                    pageCount = s.pageCount,
                    quality = it.quality,
                    skipSfx = it.skipSfx,
                    uppercase = it.uppercase,
                    rangeEnd = s.pageCount.toString(),
                    savedPages = st.savedPages(),
                )
            }
            showPage(0)
        } catch (e: Exception) {
            _state.update { it.copy(error = "Couldn't open PDF: ${e.message}") }
        }
    }

    fun showPage(index: Int) {
        val s = source ?: return
        val i = index.coerceIn(0, s.pageCount - 1)
        renderJob?.cancel()
        renderJob = viewModelScope.launch {
            _state.update { it.copy(currentPage = i, loading = true, error = null) }
            try {
                val orig = s.render(i, _state.value.quality)
                val tr = withContext(Dispatchers.IO) { store?.load(i) }
                _state.update {
                    it.copy(original = orig, translated = tr, loading = false,
                        showOriginal = if (tr == null) false else it.showOriginal)
                }
            } catch (e: OutOfMemoryError) {
                _state.update { it.copy(loading = false, error = "Out of memory — lower the quality.") }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(loading = false, error = e.message) }
            }
        }
    }

    fun setQuality(q: RenderQuality) {
        _state.update { it.copy(quality = q) }
        if (source != null) showPage(_state.value.currentPage)
    }

    fun setShowOriginal(v: Boolean) = _state.update { it.copy(showOriginal = v) }
    fun setSkipSfx(v: Boolean) = _state.update { it.copy(skipSfx = v) }
    fun setUppercase(v: Boolean) = _state.update { it.copy(uppercase = v) }
    fun setRangeStart(v: String) = _state.update { it.copy(rangeStart = v.filter(Char::isDigit)) }
    fun setRangeEnd(v: String) = _state.update { it.copy(rangeEnd = v.filter(Char::isDigit)) }

    fun translateCurrent() = translate(_state.value.currentPage, _state.value.currentPage)
    fun translateAll() = translate(0, _state.value.pageCount - 1)
    fun translateRange() {
        val st = _state.value
        val a = (st.rangeStart.toIntOrNull() ?: 1).coerceIn(1, st.pageCount)
        val b = (st.rangeEnd.toIntOrNull() ?: st.pageCount).coerceIn(1, st.pageCount)
        translate(minOf(a, b) - 1, maxOf(a, b) - 1)
    }

    fun cancelTranslation() { translateJob?.cancel() }

    private fun translate(from: Int, to: Int) {
        val s = source ?: return
        val pages = store ?: return
        if (_state.value.translating) return
        val opts = TranslateOptions(_state.value.skipSfx, _state.value.uppercase)
        val quality = _state.value.quality
        val total = to - from + 1

        translateJob = viewModelScope.launch {
            _state.update {
                it.copy(translating = true, progress = 0, total = total, error = null,
                    status = "Preparing offline model (first run downloads ~30 MB)…")
            }
            try {
                translator.ensureModel()
                for (i in from..to) {
                    ensureActive()
                    _state.update { it.copy(status = "Translating page ${i + 1} of ${s.pageCount}…") }
                    val src = s.render(i, quality)
                    val out = withContext(Dispatchers.Default) { pipeline.translatePage(src, opts) }
                    withContext(Dispatchers.IO) { pages.save(i, out) }
                    if (out !== src) out.recycle()
                    src.recycle()
                    _state.update { it.copy(progress = i - from + 1, savedPages = it.savedPages + i) }
                    if (i == _state.value.currentPage) {
                        val tr = withContext(Dispatchers.IO) { pages.load(i) }
                        _state.update { it.copy(translated = tr, showOriginal = false) }
                    }
                }
                _state.update { it.copy(status = "Done") }
            } catch (e: CancellationException) {
                _state.update { it.copy(status = "Cancelled") }
                throw e
            } catch (e: OutOfMemoryError) {
                _state.update { it.copy(error = "Out of memory — lower the render quality.") }
            } catch (e: Exception) {
                _state.update { it.copy(error = "Translation failed: ${e.message}") }
            } finally {
                _state.update { it.copy(translating = false) }
            }
        }
    }

    override fun onCleared() {
        translateJob?.cancel()
        source?.close()
        runCatching { ocr.close() }
        runCatching { translator.close() }
    }
}
