package com.manhwalens.en.ocr

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await
import kotlin.math.min

data class OcrBlock(val text: String, val rect: Rect, val lineHeight: Float)

/** ML Kit Latin OCR (covers Indonesian). Tall pages are scanned in strips for accuracy. */
class OcrEngine {
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    suspend fun detect(bmp: Bitmap): List<OcrBlock> {
        val out = mutableListOf<OcrBlock>()
        val single = bmp.height <= SINGLE_PASS_MAX
        var top = 0
        while (top < bmp.height) {
            val h = if (single) bmp.height else min(STRIP_HEIGHT, bmp.height - top)
            val strip = if (single) bmp else Bitmap.createBitmap(bmp, 0, top, bmp.width, h)
            val result = recognizer.process(InputImage.fromBitmap(strip, 0)).await()
            for (b in result.textBlocks) {
                val r = b.boundingBox ?: continue
                val heights = b.lines.mapNotNull { it.boundingBox?.height() }
                val lh = if (heights.isNotEmpty()) heights.average().toFloat() else r.height().toFloat()
                out += OcrBlock(b.text, Rect(r.left, r.top + top, r.right, r.bottom + top), lh)
            }
            if (strip !== bmp) strip.recycle()
            top += h
        }
        return out
    }

    fun close() = recognizer.close()

    private companion object {
        const val SINGLE_PASS_MAX = 3600
        const val STRIP_HEIGHT = 2400
    }
}
